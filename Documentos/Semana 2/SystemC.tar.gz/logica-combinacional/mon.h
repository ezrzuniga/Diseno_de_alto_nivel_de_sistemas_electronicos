// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Luis G. Leon Vega <l.leon@tec.ac.cr>

#pragma once

#include <iomanip>
#include <systemc.h>

SC_MODULE(mon)
{
  sc_in<bool> A;
  sc_in<bool> B;
  sc_in<bool> F;
  sc_in<bool> Clk;

  void monitor()
  {
    std::cout << std::setw(10) << "Time";
    std::cout << std::setw(2) << "A";
    std::cout << std::setw(2) << "B";
    std::cout << std::setw(2) << "F" << std::endl;
    while (true)
    {
      std::cout << std::setw(10) << sc_time_stamp();
      std::cout << std::setw(2) << A.read();
      std::cout << std::setw(2) << B.read();
      std::cout << std::setw(2) << F.read() << std::endl;
      wait();    // wait for 1 clock cycle
    }
  }

  SC_CTOR(mon)
  {
    SC_THREAD(monitor);
    sensitive << Clk.pos();
  }
};
