// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Luis G. Leon Vega <l.leon@tec.ac.cr>

#pragma once

#include <systemc.h>

SC_MODULE(stim)
{
  sc_out<bool> Reset;
  sc_out<bool> Enable;
  sc_in<bool> Clk;

  void stim_gen()
  {
    Reset.write(true);
    Enable.write(false);
    wait();

    Reset.write(false);
    Enable.write(true);
    for (int i = 0; i < 20; ++i)
    {
      wait();
    }

    Enable.write(false);
    wait();
    sc_stop();
  }

  SC_CTOR(stim)
  {
    SC_THREAD(stim_gen);
    sensitive << Clk.pos();
  }
};
