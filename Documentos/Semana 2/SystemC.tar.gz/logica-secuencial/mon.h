// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Luis G. Leon Vega <l.leon@tec.ac.cr>

#pragma once

#include <iomanip>
#include <systemc.h>

SC_MODULE(mon)
{
  sc_in<bool> Reset;
  sc_in<bool> Enable;
  sc_in<sc_uint<4>> Q;
  sc_in<bool> Clk;

  void monitor()
  {
    std::cout << std::setw(10) << "Time";
    std::cout << std::setw(8) << "Reset";
    std::cout << std::setw(8) << "Enable";
    std::cout << std::setw(8) << "Q" << std::endl;

    while (true)
    {
      std::cout << std::setw(10) << sc_time_stamp();
      std::cout << std::setw(8) << Reset.read();
      std::cout << std::setw(8) << Enable.read();
      std::cout << std::setw(8) << Q.read() << std::endl;
      wait();
    }
  }

  SC_CTOR(mon)
  {
    SC_THREAD(monitor);
    sensitive << Clk.pos();
  }
};
