// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Luis G. Leon Vega <l.leon@tec.ac.cr>

#pragma once

#include <systemc.h>

SC_MODULE(counter4)
{
  sc_in<bool> Clk;
  sc_in<bool> Reset;
  sc_in<bool> Enable;
  sc_out<sc_uint<4>> Q;

  sc_uint<4> count;

  void count_proc()
  {
    if (Reset.read())
    {
      count = 0;
    }
    else if (Enable.read())
    {
      count = count + 1;
    }

    Q.write(count);
  }

  SC_CTOR(counter4) : count(0)
  {
    SC_METHOD(count_proc);
    sensitive << Clk.pos();

    // Avoid extra-startup at time 0
    dont_initialize();
  }
};
