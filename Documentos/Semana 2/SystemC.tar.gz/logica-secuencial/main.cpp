// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Luis G. Leon Vega <l.leon@tec.ac.cr>

#include <systemc.h>

#include "counter4.h"
#include "mon.h"
#include "stim.h"

int sc_main(int argc, char* argv[])
{
  (void)argc;
  (void)argv;

  sc_signal<bool> ResetSig;
  sc_signal<bool> EnableSig;
  sc_signal<sc_uint<4>> QSig;
  sc_clock TestClk("TestClock", 10, SC_NS, 0.5);

  stim Stim1("Stimulus");
  Stim1.Reset(ResetSig);
  Stim1.Enable(EnableSig);
  Stim1.Clk(TestClk);

  counter4 DUT("counter4");
  DUT.Reset(ResetSig);
  DUT.Enable(EnableSig);
  DUT.Clk(TestClk);
  DUT.Q(QSig);

  mon Monitor1("Monitor");
  Monitor1.Reset(ResetSig);
  Monitor1.Enable(EnableSig);
  Monitor1.Q(QSig);
  Monitor1.Clk(TestClk);

  sc_start();
  return 0;
}
