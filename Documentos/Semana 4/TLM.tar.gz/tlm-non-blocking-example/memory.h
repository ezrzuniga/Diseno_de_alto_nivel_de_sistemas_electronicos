// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Luis G. Leon Vega <l.leon@tec.ac.cr>

#pragma once

#include <array>
#include <cstdint>
#include <cstring>

#include <systemc>
#include <tlm>
#include <tlm_utils/simple_target_socket.h>

struct Memory : sc_core::sc_module
{
  tlm_utils::simple_target_socket<Memory> socket;

  static constexpr unsigned int kSize = 256;

  std::array<unsigned char, kSize> data{};

  sc_core::sc_event request_event;
  tlm::tlm_generic_payload* pending_trans = nullptr;

  SC_CTOR(Memory) : socket("socket")
  {
    socket.register_nb_transport_fw(this, &Memory::nb_transport_fw);
    SC_THREAD(process_requests);
  }

  tlm::tlm_sync_enum nb_transport_fw(tlm::tlm_generic_payload& trans,
                                      tlm::tlm_phase& phase,
                                      sc_core::sc_time& delay)
  {
    if (phase != tlm::BEGIN_REQ)
    {
      SC_REPORT_ERROR("TLM-2", "Memory only accepts BEGIN_REQ on nb_transport_fw");
      return tlm::TLM_COMPLETED;
    }

    if (pending_trans != nullptr)
    {
      SC_REPORT_ERROR("TLM-2", "Memory received a new request while one is still pending");
      return tlm::TLM_COMPLETED;
    }

    pending_trans = &trans;
    request_event.notify(delay + sc_core::sc_time(5, sc_core::SC_NS));

    phase = tlm::END_REQ;
    delay = sc_core::sc_time(5, sc_core::SC_NS);
    return tlm::TLM_UPDATED;
  }

  void process_requests()
  {
    while (true)
    {
      wait(request_event);

      auto* trans = pending_trans;
      pending_trans = nullptr;

      if (trans == nullptr)
      {
        continue;
      }

      const auto cmd = trans->get_command();
      const auto addr = trans->get_address();
      auto* ptr = trans->get_data_ptr();
      const auto len = trans->get_data_length();

      if ((addr + len) > kSize)
      {
        trans->set_response_status(tlm::TLM_ADDRESS_ERROR_RESPONSE);
      }
      else if (cmd == tlm::TLM_WRITE_COMMAND)
      {
        std::memcpy(&data[addr], ptr, len);
        trans->set_response_status(tlm::TLM_OK_RESPONSE);
      }
      else if (cmd == tlm::TLM_READ_COMMAND)
      {
        std::memcpy(ptr, &data[addr], len);
        trans->set_response_status(tlm::TLM_OK_RESPONSE);
      }
      else
      {
        trans->set_response_status(tlm::TLM_COMMAND_ERROR_RESPONSE);
      }

      wait(sc_core::sc_time(10, sc_core::SC_NS));

      tlm::tlm_phase phase = tlm::BEGIN_RESP;
      sc_core::sc_time delay = sc_core::SC_ZERO_TIME;
      const auto status = socket->nb_transport_bw(*trans, phase, delay);

      if (status != tlm::TLM_COMPLETED && status != tlm::TLM_ACCEPTED)
      {
        SC_REPORT_WARNING("TLM-2", "Unexpected return from nb_transport_bw");
      }
    }
  }
};
