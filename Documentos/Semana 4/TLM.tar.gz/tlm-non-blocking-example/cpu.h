// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Luis G. Leon Vega <l.leon@tec.ac.cr>

#pragma once

#include <cstdint>
#include <iomanip>
#include <iostream>

#include <systemc>
#include <tlm>
#include <tlm_utils/simple_initiator_socket.h>

struct CPU : sc_core::sc_module
{
  tlm_utils::simple_initiator_socket<CPU> socket;

  sc_core::sc_event response_event;

  SC_CTOR(CPU) : socket("socket")
  {
    socket.register_nb_transport_bw(this, &CPU::nb_transport_bw);
    SC_THREAD(run);
  }

  void run()
  {
    std::uint32_t write_value = 0x1234ABCD;
    send_transaction(tlm::TLM_WRITE_COMMAND, 0x10, write_value);

    std::uint32_t read_value = 0;
    send_transaction(tlm::TLM_READ_COMMAND, 0x10, read_value);

    std::cout << sc_core::sc_time_stamp() << " CPU read value = 0x"
              << std::hex << std::setw(8) << std::setfill('0') << read_value
              << std::dec << std::setfill(' ') << std::endl;

    sc_core::sc_stop();
  }

  void send_transaction(tlm::tlm_command cmd, std::uint64_t addr, std::uint32_t& value)
  {
    tlm::tlm_generic_payload trans;
    tlm::tlm_phase phase = tlm::BEGIN_REQ;
    sc_core::sc_time delay = sc_core::SC_ZERO_TIME;

    trans.set_command(cmd);
    trans.set_address(addr);
    trans.set_data_ptr(reinterpret_cast<unsigned char*>(&value));
    trans.set_data_length(sizeof(value));
    trans.set_streaming_width(sizeof(value));
    trans.set_byte_enable_ptr(nullptr);
    trans.set_dmi_allowed(false);
    trans.set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);

    const auto status = socket->nb_transport_fw(trans, phase, delay);

    if (status == tlm::TLM_COMPLETED)
    {
      wait(delay);
    }
    else if (status == tlm::TLM_UPDATED && phase == tlm::END_REQ)
    {
      wait(delay);
    }
    else if (status != tlm::TLM_ACCEPTED)
    {
      SC_REPORT_ERROR("TLM-2", "Unexpected return from nb_transport_fw");
    }

    wait(response_event);

    if (trans.is_response_error())
    {
      SC_REPORT_ERROR("TLM-2", trans.get_response_string().c_str());
    }
  }

  tlm::tlm_sync_enum nb_transport_bw(tlm::tlm_generic_payload& trans,
                                     tlm::tlm_phase& phase,
                                     sc_core::sc_time& delay)
  {
    if (phase == tlm::BEGIN_RESP)
    {
      response_event.notify(delay);
      return tlm::TLM_COMPLETED;
    }

    return tlm::TLM_ACCEPTED;
  }
};
