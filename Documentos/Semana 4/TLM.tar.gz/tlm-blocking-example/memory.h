// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Luis G. Leon Vega <l.leon@tec.ac.cr>

#pragma once

#include <array>
#include <cstdint>
#include <cstring>

#include <systemc>
#include <tlm>
#include <tlm_utils/simple_target_socket.h>

struct Memory : sc_core::sc_module
{
  tlm_utils::simple_target_socket<Memory> socket;

  static constexpr unsigned int kSize = 256;
  std::array<unsigned char, kSize> data{};

  SC_CTOR(Memory) : socket("socket")
  {
    socket.register_b_transport(this, &Memory::b_transport);
  }

  void b_transport(tlm::tlm_generic_payload& trans, sc_core::sc_time& delay)
  {
    const auto cmd = trans.get_command();
    const auto addr = trans.get_address();
    auto* ptr = trans.get_data_ptr();
    const auto len = trans.get_data_length();

    if ((addr + len) > kSize)
    {
      trans.set_response_status(tlm::TLM_ADDRESS_ERROR_RESPONSE);
      return;
    }

    if (cmd == tlm::TLM_WRITE_COMMAND)
    {
      std::memcpy(&data[addr], ptr, len);
    }
    else if (cmd == tlm::TLM_READ_COMMAND)
    {
      std::memcpy(ptr, &data[addr], len);
    }

    delay += sc_core::sc_time(10, sc_core::SC_NS);
    trans.set_response_status(tlm::TLM_OK_RESPONSE);
  }
};
