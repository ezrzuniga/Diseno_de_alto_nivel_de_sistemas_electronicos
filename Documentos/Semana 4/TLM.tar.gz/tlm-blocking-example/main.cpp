// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Luis G. Leon Vega <l.leon@tec.ac.cr>

#include <systemc>

#include "cpu.h"
#include "memory.h"

int sc_main(int argc, char* argv[])
{
  (void)argc;
  (void)argv;

  CPU cpu("cpu");
  Memory memory("memory");

  cpu.socket.bind(memory.socket);

  sc_core::sc_start();
  return 0;
}
