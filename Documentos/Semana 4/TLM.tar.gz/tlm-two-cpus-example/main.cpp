// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Luis G. Leon Vega <l.leon@tec.ac.cr>

#include <systemc>

#include "bus.h"
#include "cpu.h"
#include "memory.h"

int sc_main(int argc, char* argv[])
{
  (void)argc;
  (void)argv;

  Bus bus("bus");
  Memory memory("memory");

  CPU cpu0("cpu0", 0x0000, 0xAAAA1111, sc_core::SC_ZERO_TIME);
  CPU cpu1("cpu1", 0x0100, 0xBBBB2222, sc_core::sc_time(5, sc_core::SC_NS));

  cpu0.socket.bind(bus.cpu0_socket);
  cpu1.socket.bind(bus.cpu1_socket);
  bus.memory_socket.bind(memory.socket);

  sc_core::sc_start();
  return 0;
}
