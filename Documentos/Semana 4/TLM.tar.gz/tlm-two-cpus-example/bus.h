// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Luis G. Leon Vega <l.leon@tec.ac.cr>

#pragma once

#include <iostream>

#include <systemc>
#include <tlm>
#include <tlm_utils/simple_initiator_socket.h>
#include <tlm_utils/simple_target_socket.h>

struct Bus : sc_core::sc_module
{
  tlm_utils::simple_target_socket<Bus> cpu0_socket;
  tlm_utils::simple_target_socket<Bus> cpu1_socket;
  tlm_utils::simple_initiator_socket<Bus> memory_socket;

  sc_core::sc_mutex bus_mutex;

  SC_CTOR(Bus)
      : cpu0_socket("cpu0_socket")
      , cpu1_socket("cpu1_socket")
      , memory_socket("memory_socket")
  {
    cpu0_socket.register_b_transport(this, &Bus::b_transport_cpu0);
    cpu1_socket.register_b_transport(this, &Bus::b_transport_cpu1);
  }

  void b_transport_cpu0(tlm::tlm_generic_payload& trans, sc_core::sc_time& delay)
  {
    route("cpu0", trans, delay);
  }

  void b_transport_cpu1(tlm::tlm_generic_payload& trans, sc_core::sc_time& delay)
  {
    route("cpu1", trans, delay);
  }

  void route(const char* source, tlm::tlm_generic_payload& trans, sc_core::sc_time& delay)
  {
    bus_mutex.lock();

    std::cout << sc_core::sc_time_stamp() << " BUS from " << source
              << " addr=0x" << std::hex << trans.get_address()
              << std::dec << std::endl;

    delay += sc_core::sc_time(2, sc_core::SC_NS);
    memory_socket->b_transport(trans, delay);

    bus_mutex.unlock();
  }
};
