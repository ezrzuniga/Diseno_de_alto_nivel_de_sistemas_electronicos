// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Luis G. Leon Vega <l.leon@tec.ac.cr>

#pragma once

#include <cstdint>
#include <iomanip>
#include <iostream>

#include <systemc>
#include <tlm>
#include <tlm_utils/simple_initiator_socket.h>

struct CPU : sc_core::sc_module
{
  tlm_utils::simple_initiator_socket<CPU> socket;

  const std::uint64_t base_addr;
  const std::uint32_t write_pattern;
  const sc_core::sc_time start_offset;

  SC_HAS_PROCESS(CPU);

  CPU(sc_core::sc_module_name name,
      std::uint64_t base_addr_,
      std::uint32_t write_pattern_,
      sc_core::sc_time start_offset_)
      : sc_core::sc_module(name)
      , socket("socket")
      , base_addr(base_addr_)
      , write_pattern(write_pattern_)
      , start_offset(start_offset_)
  {
    SC_THREAD(run);
  }

  void run()
  {
    wait(start_offset);

    std::uint32_t write_value = write_pattern;
    send_transaction(tlm::TLM_WRITE_COMMAND, base_addr + 0x10, write_value);

    std::uint32_t read_value = 0;
    send_transaction(tlm::TLM_READ_COMMAND, base_addr + 0x10, read_value);

    std::cout << sc_core::sc_time_stamp() << " " << name()
              << " read value = 0x"
              << std::hex << std::setw(8) << std::setfill('0') << read_value
              << std::dec << std::setfill(' ') << std::endl;
  }

  void send_transaction(tlm::tlm_command cmd, std::uint64_t addr, std::uint32_t& value)
  {
    tlm::tlm_generic_payload trans;
    sc_core::sc_time delay = sc_core::SC_ZERO_TIME;

    trans.set_command(cmd);
    trans.set_address(addr);
    trans.set_data_ptr(reinterpret_cast<unsigned char*>(&value));
    trans.set_data_length(sizeof(value));
    trans.set_streaming_width(sizeof(value));
    trans.set_byte_enable_ptr(nullptr);
    trans.set_dmi_allowed(false);
    trans.set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);

    socket->b_transport(trans, delay);
    wait(delay);

    if (trans.is_response_error())
    {
      SC_REPORT_ERROR("TLM-2", trans.get_response_string().c_str());
    }
  }
};
